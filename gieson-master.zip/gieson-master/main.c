#include "mylib.h"
#include <stdio.h>
#include <stdlib.h>
#include "gamelib.h"

int main (void) {
	int azione;
	do {
	printf("%s","Cosa vuoi fare?\n1) crea mappa\n2) gioca\n3) termina gioco\n");
	scanf ("%d", &azione);
	switch (azione) {
		case 1:
			crea_mappa();
			break;
		case 2:
			gioca();
			break;
		case 3:
			termina_gioco();
			break;
		default:
			printf( "%s","il comando è sbagliato, riprova\n1) crea mappa\n2) gioca\n3) termina gioco\n");
		}
	}while(azione!=3);
}
/* Questo file contiene solo la stampa del menu principale e poi richiama una delle
 tre funzioni possibili: crea_mappa(), gioca(), termina_gioco(). */



