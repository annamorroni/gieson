# gieson
Progetto di esame Programmazione I a.a. 2017/2017.
Seguire il testo d'esame, anche se cono incoraggiate scelte alternative.
Ricordate che in sede di orale vi chiederò di modificare il progetto.


Aggiungere qui sotto il 

Nome:             Anna
Cognome:          Morroni
Matricola:        289193
