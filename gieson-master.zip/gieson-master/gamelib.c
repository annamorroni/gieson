#include "mylib.h"
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <time.h>
#include "gamelib.h"

static struct Zona* prima_zona=NULL;
static struct Zona* ultima_zona=NULL;
static struct Zona* penultima_zona=NULL;
static struct Zona* appoggio=NULL;
static int contatorezone=0;

int achitocca; //variabile che stabilisce di chi è il turno (0 se di Marzia, 1 se di Giacomo)
int mconosceogg; //variabile che stabilisce se Marzia conosce l'oggetto nella stanza in cui si trova
int gconosceogg; //variabile che stabilisce se Giacomo conosce l'oggetto nella stanza in cui si trova
int h;          //questa variabile mi serve nel caso uno dei due abbia la benzina
int w;         //variabile per stabilire se attualmente esiste una mappa, 0 se no, 1 se sì
static struct Giocatore marzia;
static struct Giocatore giacomo;

static int avanza();
static int mostra_oggetto();
static int prendi_oggetto();
static int cura();
static int usa_adrenalina();
static int incontra_Gieson();
static int Gieson();
static int ins_zona();
static int canc_zona();
static int stampa_mappa();
static int chiudi_mappa();
static int controlla_benzina();
static int turno1();
static int turno2();
static int stampa_menu();

int crea_mappa(){
	if(w==1){
		appoggio=prima_zona;
		for(int k=0;k<contatorezone;k++){
			penultima_zona=appoggio->zona_successiva;
			free(appoggio);
			appoggio=penultima_zona;
			penultima_zona=NULL;
		}
	}
	w=0;
	int comando;
	int controllo=1;
	do{
		printf( "Cosa vuoi fare?\n1)inserisci una zona\n2)cancella una zona\n3)stampa la mappa\n4)chiudi la mappa\n" );
		scanf ( "%d", &comando ); //legge cosa vuole fare l'utente
		switch (comando) {
			case 1:
				ins_zona();
				break;
			case 2:
				canc_zona();
				break;
			case 3:
				stampa_mappa();
				break;
			case 4:
				if (contatorezone<8){
					printf("devi creare almeno 8 zone!\nNe hai create solo %d\n",contatorezone); //controlla che ci sono almeno 8 zone
				}
				else if(ultima_zona->zona!=uscita_campeggio){
					printf("%s","l'ultima zona deve essere l'uscita campeggio\n"); //controlla che l'ultima zone sia l'uscita campeggio
				}
				else{
					int i; //controllo che soltanto l'ultima zona sia di tipo uscita campeggio
					int e=0;
					appoggio=prima_zona;
					for(i=0;i<contatorezone-1;i++){
						if(appoggio->zona==uscita_campeggio){
							e++;		//la variabile e conta quante zone sono di tipo uscita campeggio (escludendo l'ultima)
						}
					appoggio=appoggio->zona_successiva;
					}
					if(e>0){
						printf("%s","solo l'ultima zona può essere un'uscita campeggio\n");
					}
					else{
						w=1;
						controllo=chiudi_mappa(); /* la variabile controllo è inizializzata a 1 e la funzione chiudi mappa riporta il valore 0, così si può uscire dalla mappa 											solo se	sono verificate tutte le condizioni*/
					}
				}
				break;
			default:
				printf ("%s","non valido, i valori possibili sono: 1, 2, 3 e 4\nriprova!\n");
				break;
		}
	}while(controllo==1);
}

static int ins_zona() {
	int cheogg; //cheogg è la variabile che stabilisce l'oggetto in ogni stanza
	cheogg=rand()%10;
	int b;
	appoggio=malloc(sizeof(struct Zona));
	appoggio->zona_successiva=NULL;
	do {
		printf ("%s","che tipo di zona vuoi creare?\n1)cucina\n2)soggiorno\n3)rimessa\n4)strada\n5)lungo lago\n6)uscita_campeggio\n(devi creare almeno 8 zone e l'ultima deve essere l'uscita 				campeggio\n");
		scanf ("%d",&b);//legge il tipo di zona che vuole inserire l'utente
		switch (b) {
			case 1:
				appoggio->zona=cucina;
				if(cheogg==0){
					appoggio->oggetto=adrenalina;
				}
				else if(cheogg==1||cheogg==2||cheogg==3){
					appoggio->oggetto=cianfrusaglia;
				}
				else if(cheogg==4||cheogg==5){
					appoggio->oggetto=bende;
				}
				else{
					appoggio->oggetto=coltello;
				}
				break;
			case 2:
				appoggio->zona=soggiorno;
				if(cheogg==0||cheogg==1){
					appoggio->oggetto=cianfrusaglia;
				}
				else if(cheogg==2){
					appoggio->oggetto=bende;
				}
				else if(cheogg==3){
					appoggio->oggetto=coltello;
				}
				else if (cheogg=4||cheogg==5||cheogg==6){
					appoggio->oggetto=pistola;
				}
				else{
					appoggio->oggetto=adrenalina;
				}
				break;
			case 3:
				appoggio->zona=rimessa;
				if(cheogg==0||cheogg==1){
					appoggio->oggetto=cianfrusaglia;
				}
				else if(cheogg==2){
					appoggio->oggetto=bende;
				}
				else if(cheogg==3||cheogg==4||cheogg==5){
				appoggio->oggetto=benzina;
				}
				else if (cheogg==6){
					appoggio->oggetto=adrenalina;
				}
				else{
					appoggio->oggetto=coltello;
				}
				break;
			case 4:
				appoggio->zona=strada;
				if(cheogg==0){
					appoggio->oggetto=benzina;
				}
				else if(cheogg==1){
					appoggio->oggetto=coltello;
				}
				else{
					appoggio->oggetto=cianfrusaglia;
				}
				break;
			case 5:
				appoggio->zona=lungo_lago;
				if(cheogg==0){
					appoggio->oggetto=coltello;
				}
				else if(cheogg==1||cheogg==2){
					appoggio->oggetto=benzina;
				}
				else{
					appoggio->oggetto=cianfrusaglia;
				}
				break;
			case 6:
				appoggio->zona=uscita_campeggio;
				if (cheogg==0){
					appoggio->oggetto=coltello;
				}
				else{
					appoggio->oggetto=cianfrusaglia;
				}
				break;
			default:
				printf ("%s","non valido\ni valori possibili sono:\n1, 2, 3, 4 e 5\n");
				break;
		}
	}while(b!=1&&b!=2&&b!=3&&b!=4&&b!=5&&b!=6);
	if(contatorezone==0){                //se il contatore zone è a 0 significa che è la prima zona, quindi assegno al puntatore prima_zona l'indirizzo di appoggio
		prima_zona=appoggio;
		ultima_zona=appoggio;                   //assegno il valore di appoggio anche a ultima e penultima zona perché attualmente appoggio è l'unica zona esistente
		penultima_zona=appoggio;
		appoggio=NULL;               
		contatorezone++;       
	}
	else{
		if(contatorezone==1){
			prima_zona->zona_successiva=appoggio;    
			ultima_zona=appoggio;
			appoggio=NULL;
			contatorezone++;
		}
		else{
			ultima_zona->zona_successiva=appoggio;
			penultima_zona=ultima_zona;
			ultima_zona=appoggio;
			appoggio=NULL;
			contatorezone++;
		}
	}
}

static int canc_zona() {
	int i;
	if(contatorezone==0){
		printf("%s","non hai ancora creato nessuna zona, riprova!");
	}
	else{
		if(contatorezone==1){
			free(prima_zona);
			prima_zona=NULL;
			penultima_zona=NULL;
			ultima_zona=NULL;
			contatorezone--;
			printf("%s","hai cancellato tutte le zone\n");
		}
		else{
			free(ultima_zona);
			penultima_zona->zona_successiva=NULL;
			ultima_zona=penultima_zona;
			penultima_zona=prima_zona;
			for(i=1;i<=contatorezone-3;i++) {
				appoggio=penultima_zona;
				penultima_zona=appoggio->zona_successiva;
				appoggio=NULL;
			}
			contatorezone--;
		}
	}
}

static int stampa_mappa () {
	char *vett[]={"cucina","soggiorno","rimessa","strada","lungo lago","uscita campeggio"};
	//char *ogg[]={"cianfrusaglia","bende","coltello","pistola","benzina","adrenalina"};
	if(prima_zona==NULL){
		printf("%s","non hai ancora creato nessuna zona, riprova!");
	}
	else{
		int i;
		appoggio=prima_zona;
		for(i=1;i<=contatorezone;i++) {
			printf ("la zona %d è %s, l'indririzzo della sua successiva è %p\n", i ,vett[appoggio->zona],appoggio->zona_successiva);
			//printf ("ogg=%s\n\n",ogg[appoggio->oggetto]);
			appoggio=appoggio->zona_successiva;
		}
	}//non sapevo se dovevo stampare gli oggetti, quindi li ho messi a commento
}

static int chiudi_mappa() {
    return 0;
}

int gioca(){
	if(w==0){
		printf("%s","devi prima creare una mappa\n");
	}
	else if (w==1){
		marzia.zaino[5]=2; //marzia ha 2 adrenaline
		giacomo.zaino[2]=1; //giacomo ha 1 coltello
		marzia.stato=0;       //all'inizio Marzia e Giacomo sono allo stato vivo
		giacomo.stato=0;
		marzia.posizione=prima_zona; 
		giacomo.posizione=prima_zona;
		srand(time(NULL));
		do{
			turno1();
			stampa_menu();
			controlla_benzina();
			turno2();
			stampa_menu();
			controlla_benzina();
		}while(achitocca!=2);
		termina_gioco();
	}
}

static int avanza(){
	char *pos[]={"cucina","soggiorno","rimessa","strada","lungo lago","uscita campeggio"};
	if(achitocca==0){
		if(marzia.posizione==ultima_zona){
			printf ("%s","complimenti Marzia! Hai finito il gioco!\n");
			marzia.stato=morto;   //nel caso uno dei due vinca gli assegno lo stato morto, così non compierà più dei turni       
		}
		else{
			marzia.posizione=marzia.posizione->zona_successiva;
			printf("Marzia si è spostata di una posizione, ora si trova in %s\n",pos[marzia.posizione->zona]);
			mconosceogg=0;        // azzero la variabile ogni volta che si sposta di una stanza
		}
	}
	else {
		if(giacomo.posizione==ultima_zona){
			printf("%s","complimenti Giacomo! Hai finito il gioco!\n");
			giacomo.stato=morto;
		}
		else{
			giacomo.posizione=giacomo.posizione->zona_successiva;
			printf("Giacomo si è spostato di una posizione, ora si trova in %s\n",pos[giacomo.posizione->zona]);
			gconosceogg=0;
		}
	}
}

static int mostra_oggetto(){
	char *ogg[]={"cianfrusaglia","bende","coltello","pistola","benzina","adrenalina"};
	if(achitocca==0){
		mconosceogg=1;
		printf("l'oggetto in questa stanza è %s\n",ogg[marzia.posizione->oggetto]);
	}
	else{
		gconosceogg=1;
		printf("l'oggetto in questa stanza è %s\n",ogg[giacomo.posizione->oggetto]);
	}
}

static int prendi_oggetto(){
	if(achitocca==0){
		if(mconosceogg==0){
			printf ("%s","errore, non conosci l'oggetto di questa stanza, hai perso un turno \n");   // prima controlla che Marzia conosca l'oggetto
		}
		else {
			marzia.zaino[marzia.posizione->oggetto]++;
			printf("%s","oggetto aggiunto\n");
		}
	}
	else{
		if(gconosceogg==0){
			printf ("%s","errore, non conosci l'oggetto di questa stanza, hai perso un turno \n");   
		}
		else {
			giacomo.zaino[giacomo.posizione->oggetto]++;
			printf("%s","oggetto aggiunto\n");
		}
	}
}


static int cura(){
	if(achitocca==0){
		if (marzia.stato==ferito&&marzia.zaino[1]>0){  //controlla che Marzia sia ferita e che abbia le bende
			marzia.stato=vivo;
			marzia.zaino[1]--;
			printf("%s","ti sei curata!\n");
		}
		else{
			printf("%s","errore\n o non sei ferita o non hai le bende, hai perso un turno\n");
		}
	}
	else if (achitocca==1){
		if (giacomo.stato==ferito&&giacomo.zaino[1]>0){
			giacomo.stato=vivo;
			giacomo.zaino[1]--;
			printf("%s","ti sei curato!\n");
		}
		else{
			printf("%s","errore\n o non sei ferito o non hai le bende, hai perso un turno\n");
		}
	}
}

static int usa_adrenalina(){
	if(achitocca==0){
		if(marzia.zaino[5]>0){
			marzia.zaino[5]--;
			int i;
			for(i=0;i<2;i++){
				printf("%s","Cosa vuoi fare?\n1)avanza\n2)mostra oggetto\n3)prendi oggetto\n4)cura\n5)usa adrenalina\n");
				int a;// COSA VUOL FARE L'UTENTE=a
				scanf("%d",&a);
				switch(a){
				case 1:
					avanza();
					break;
				case 2:
					mostra_oggetto();
					break;
				case 3:
					prendi_oggetto();
					break;
				case 4:
					cura();
					break;
				case 5:
					usa_adrenalina();
					 break;
				default:
					printf ("%s"," non valido, i valori possibili sono: 1, 2, 3 ,4 e 5\nriprova!\n");
					i--;
					break;
				}
			}
		}
		else{
			printf("%s","errore, non hai nessuna adrenalina, hai perso un turno\n");
		}
	}
	else if(achitocca==1){
		if(giacomo.zaino[5]>0){
			giacomo.zaino[5]--;
			int i;
			for(i=0;i<2;i++){
				printf("%s","Cosa vuoi fare?\n1)avanza\n2)mostra oggetto\n3)prendi oggetto\n4)cura\n5)usa adrenalina\n");
				int a;// COSA VUOL FARE L'UTENTE=a
				scanf("%d",&a);
				switch(a){
				case 1:
					avanza();
					break;
				case 2:
					mostra_oggetto();
					break;
				case 3:
					prendi_oggetto();
					break;
				case 4:
					cura();
					break;
				case 5:
					usa_adrenalina();
					 break;
				default:
					printf ("%s"," non valido, i valori possibili sono: 1, 2, 3 ,4 e 5\nriprova!\n");
					i--;
					break;
				}
			}
		}
		else{
			printf("%s","errore, non hai nessuna adrenalina, hai perso un turno\n");
		}
	}
}

static int incontra_Gieson(){
	int gieson;
	if(achitocca==0){
		if(marzia.posizione==ultima_zona){
			gieson=rand()%4;
			if (gieson!=0){
				return 1;//incontra Gieson
			}
		}
		else if(giacomo.stato==morto){
			gieson=rand()%2;
			if (gieson!=0){
				return 1;
			}
		}
		else {
			gieson=rand()%10;
			if (gieson==0||gieson==1||gieson==2){
				return 1;
			}
		}
	}
	else if (achitocca==1){
        	if(marzia.posizione==ultima_zona){
			gieson=rand()%4;
			if (gieson!=0){
				return 1;
			}
		}
		else if(giacomo.stato==morto){
			gieson=rand()%2;
			if (gieson!=0){
				return 1;
			}
		}
		else {
			gieson=rand()%10;
			if (gieson==0||gieson==1||gieson==2){
				return 1;
			}
		}
	}
	return 0;//non incontra Gieson
}

static int Gieson() {
    int v;
    printf ("%s","Oh no! Hai incontrato Gieson!\n");
    if(achitocca==0){
        if(marzia.zaino[2]>0&&marzia.zaino[3]>0){
            printf("%s","Marzia, hai sia un coltello che una pistola, cosa vuoi usare per difenderti?\n1) coltello\n2) pistola\n(se sei ferita usando il coltello morirai)\n");
            scanf("%d",&v);
            do{
                switch (v) {
                    case 1:
                        if(marzia.stato==ferito){
                            marzia.stato=morto;
                            printf("%s","Oh no! Sei morta!\n");
				
                        }
                        else{
                            marzia.stato=ferito;
                            printf("%s","Sei salva, ma sei stata ferita!\n");
                        }
                        break;
                    case 2:
                        printf("%s","sei salva!\n");
                        break;
                    default:
                        printf("%s","errore, riprova\n");
                        break;
                }
            }while(v!=2&&v!=1);
        }
        else if(marzia.zaino[2]>0&&marzia.zaino[3]==0){
            if(marzia.stato==ferito){
                marzia.stato=morto;
                printf("%s","Oh no! Sei morta! Non avevi una pistola ed eri ferita!\n");
		
            }
            else{
                marzia.stato=ferito;
                printf("%s","Avevi il coltello! Sei salva, ma sei stata ferita!\n");
            }
        }
        else if(marzia.zaino[2]==0&&marzia.zaino[3]>0){
            printf("%s","Sei salva! avevi la pistola!\n");
        }
        else{
            printf("%s","Non avevi nè il coltello nè la pistola! Sei morta!\n");
            marzia.stato=morto;
		
        }
    }
    else if (achitocca==1){
        if(giacomo.zaino[2]>0&&giacomo.zaino[3]>0){
            printf("%s","Giacomo, hai sia un coltello che una pistola, cosa vuoi usare per difenderti?\n1) coltello\n2) pistola\n(se sei ferito usando il coltello morirai)\n");
            scanf("%d",&v);
            do{
                switch (v) {
                    case 1:
                        if(giacomo.stato==ferito){
                            giacomo.stato=morto;
                            printf("%s","Oh no! Sei morto!\n");
				
                        }
                        else{
                            giacomo.stato=ferito;
                            printf("%s","Sei salvo, ma sei stata ferito!\n");
                        }
                        break;
                    case 2:
                        printf("%s","sei salvo!\n");
                        break;
                    default:
                        printf("%s","errore, riprova\n");
                        break;
                }
            }while(v!=2&&v!=1);
        }
        else if(giacomo.zaino[2]>0&&giacomo.zaino[3]==0){
            if(giacomo.stato==ferito){
                giacomo.stato=morto;
		
                printf("%s","Oh no! Sei morto! Non avevi una pistola ed eri ferito!\n");
            }
            else{
                giacomo.stato=ferito;
                printf("%s","Avevi il coltello! Sei salvo, ma sei stato ferito!\n");
            }
        }
        else if(giacomo.zaino[2]==0&&giacomo.zaino[3]>0){
            printf("%s","Sei salvo! avevi la pistola!\n");
        }
        else{
            printf("%s","Non avevi nè il coltello nè la pistola! Sei morto!\n");
            giacomo.stato=morto;
		
        }
    }
}

int termina_gioco(){
    printf("%s","Game Over\n");
    appoggio=prima_zona;
    for(int k=0;k<contatorezone;k++){
        penultima_zona=appoggio->zona_successiva;
        free(appoggio);
        appoggio=penultima_zona;
        penultima_zona=NULL;
    }   
}

static int controlla_benzina(){
    int g; //è la variabile che stabilisce se alla fine del turno incontreranno Gieson, 0 se no, 1 se sì
	if(marzia.zaino[4]>0){
                marzia.zaino[4]--;    //se Marzia prende la benzina viene usata in automatico e tolta dal suo zaino, h viene incrementata di 4
                h += 4;
            }
            else if (giacomo.zaino[4]>0){
                giacomo.zaino[4]--;
                h += 4;
            }
            else if(h==0){
                if(achitocca==0&&marzia.stato!=morto){
                    g=incontra_Gieson();
                    if(g==1){
                        Gieson();
                    }
                }
                if(achitocca==1&&giacomo.stato!=morto){
                    g=incontra_Gieson();
                    if(g==1){
                        Gieson();
                    }
                }
            }
           
            if(h>0){
                h--;               /*ogni fine turno h viene decrementata di 1, a meno che non sia a 0, così si usa l'effetto della benzina per cui non si incontra Gieson per 4 turni*/
            }
}

static int turno1(){
	if(marzia.stato!=morto&&giacomo.stato!=morto){   
        	achitocca=rand()%2; 
        }
        else if(marzia.stato==morto&&giacomo.stato!=morto){ //se Marzia è morta assegna il turno a Giacomo
            achitocca=1;
        }
        else if(marzia.stato!=morto&&giacomo.stato==morto){ // se Giacomo è morto assegna il turno a Marzia
            achitocca=0;
        }
	else if(marzia.stato==morto&&giacomo.stato==morto){
		achitocca=2;
	}
        if(achitocca==0){
            printf("%s","ora tocca a Marzia!\n");
        }
        else if(achitocca==1){
            printf("%s","ora tocca a Giacomo!\n");
        }
}

static int turno2(){
	if(marzia.stato!=morto&&giacomo.stato!=morto){
                if(achitocca==0){
                    achitocca=1;
                }
                else if(achitocca==1){
                    achitocca=0;
                }
            }
            else if(marzia.stato==morto&&giacomo.stato!=morto){
                achitocca=1;
            }
            else if(giacomo.stato==morto&&marzia.stato!=morto){
                achitocca=0;
            }
            else if (marzia.stato==morto&&giacomo.stato==morto){
                achitocca=2;
            }
            if(achitocca==0){
                printf("%s","ora tocca a Marzia\n");
            }
            else if(achitocca==1){
                printf("%s","ora tocca a Giacomo!\n");
            }
}

static int stampa_menu(){
	int a; //è la variabile che legge il comando da tastiera
	if(achitocca!=2){
            do{
                printf("%s","Cosa vuoi fare?\n1)avanza\n2)mostra oggetto\n3)prendi oggetto\n4)cura\n5)usa adrenalina\n");
                scanf("%d",&a);
                switch(a){
                case 1:
                    avanza();
                    break;
                case 2:
                    mostra_oggetto();
                    break;
                case 3:
                    prendi_oggetto();
                    break;
                case 4:
                    cura();
                    break;
                case 5:
                    usa_adrenalina();
                    break;
                default:
                    printf ("%s"," non valido, i valori possibili sono: 1, 2, 3 ,4 e 5\nriprova!\n");
                    break;
                }
            }while(a!=1&&a!=2&&a!=3&&a!=4&&a!=5);
	}
}


/* Questo file contiene le definizioni di tutte le funzioni da implementare.
   Quelle visibili in main crea_mappa(), gioca(), termina_gioco() hanno linkage esterno.
   Tutte le funzioni non visibili in main.c e definite qui, devono avere linkage interno.
   Tutte le variabili globali definite in questo file devono avere linkage interno.
   Per esempio, la matrice con zone/probabilita' */
