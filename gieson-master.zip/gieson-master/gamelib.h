struct Giocatore{
	enum stato_giocatore {vivo,ferito,morto} stato;
	struct Zona* posizione;
	unsigned short zaino[6];
};
struct Zona{
	enum Tipo_zona {cucina,soggiorno,rimessa,strada,lungo_lago,uscita_campeggio} zona;
	enum Tipo_oggetto {cianfrusaglia,bende,coltello,pistola,benzina,adrenalina} oggetto;
	struct Zona* zona_successiva;
};
int crea_mappa (void);
int gioca(void);
int termina_gioco(void);
/* Questo file contiene le dichiarazioni delle funzioni crea_mappa(), gioca(), termina_gioco().
 Continene anche le definizioni dei tipi utilizzati in gamelib.c:
 struct Giocatore, struct Zona, enum Stato_giocatore, enum Tipo_zona, enum Tipo_oggetto. */
